#!/usr/bin/bash
COMPILER="g++"

FLAGS="-std=c++17"


SFML_LIBS="-lsfml-graphics -lsfml-window -lsfml-system"

OTHER_FLAGS="-no-pie"


SOURCE="main.cpp"

OUTPUT="sfml-app"


echo "Компиляция $SOURCE..."


$COMPILER $SOURCE -o $OUTPUT $SFML_LIBS $OTHER_FLAGS


if [ $? -eq 0 ]; then
    echo "Успешно скомпилировано в $OUTPUT"
    echo "Запуск программы..."
    ./$OUTPUT
else
    echo "Ошибка компиляции!"
    exit 1
fi