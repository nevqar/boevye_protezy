#include <SFML/Graphics.hpp>
#include <iostream> // для std::cout
#include <fstream>  // для std::ifstream
#include <string>   
#include <vector>





using namespace sf;
using namespace std;

int main()
{
    sf::VideoMode desktopMode = sf::VideoMode::getDesktopMode();
    sf::RenderWindow window(desktopMode, "Smooth Walls Movement", sf::Style::Fullscreen);
    
   
    sf::Sprite con_button;
    sf::Texture texture;
    texture.loadFromFile("files/conn.png");
    con_button.setTexture(texture);
    con_button.setPosition(
        window.getSize().x / 2 - con_button.getGlobalBounds().width / 2,
        window.getSize().y / 2 - con_button.getGlobalBounds().height / 2
    );

    Sprite console_text;
    Texture console_textu;
    console_textu.loadFromFile("files/console_txt.png");
    console_text.setTexture(console_textu);
     console_text.setPosition(
        window.getSize().x / 2 - console_text.getGlobalBounds().width / 2,
        window.getSize().y / 2 - console_text.getGlobalBounds().height / 2
    );

   
    vector<string> name;
    window.setActive(true); 
    bool button_pres = 0;
    bool sc_sensor = 0;
    bool scan_num_sens = 0;
   
  
    //     );
    while(window.isOpen()){
         sf::Event event;
         while(window.pollEvent(event)){
             if (event.type == sf::Event::Closed){
                window.close();
             }
             if(event.type == sf::Event::KeyPressed){
                if(event.key.code == sf::Keyboard::Escape){
                    window.close();
                }
             }
          
             if(event.type == sf::Event::MouseButtonPressed){
                 if(event.mouseButton.button == sf::Mouse::Left){
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                   sf::FloatRect buttonBounds = con_button.getGlobalBounds();
                    
                    if(buttonBounds.contains(mousePos.x, mousePos.y) && !button_pres){
                        window.clear();
                        // window.draw(console_text);



                        button_pres= 1;
                      
                       
                        
                     }

             }
         }
       
      
        if(button_pres && !sc_sensor){
            

        
            
            //получаем данные
         
            ifstream fnames("names.cfg");
            string nam = "";
            while(getline(fnames,nam)){

                name.push_back(nam);
            }
            
            fnames.close();
            if(name.empty()){
                cout<<"Случилась неплановая ошибка.Пожалуйста презапустите программу"<<endl;
                window.close();

            }
            else{
              
                sc_sensor = 1;
                cout<<"Считали название датчиков,выберите нужный для вас . Для этого нажмите соответсвующий ему номер"<<endl;
                for(int i = 0;i<name.size();i++){
                    cout<<i+1<<" "<<name[i]<<endl;
                }
            
         

            }
            
            


         }
        
           

        }
  
        window.clear();
       if(!button_pres) {
            window.draw(con_button);


       }
       else{
         if(!scan_num_sens){
            int number;
            window.draw(console_text);
             if(cin.peek() != EOF){
                cin >> number;
                
                ofstream file("num.cfg");
                file << number;
                file.close();
                scan_num_sens = true;
               
            }
          
        }
       
       

       }
   
       
       
   

       
        window.display();
        
    
}
    return 0;
}